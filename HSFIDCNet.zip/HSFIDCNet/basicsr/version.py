# GENERATED VERSION FILE
# TIME: Wed Sep 22 01:31:26 2021
__version__ = '1.3.4.2'
__gitsha__ = '0e55b20'
version_info = (1, 3, 4, 2)
